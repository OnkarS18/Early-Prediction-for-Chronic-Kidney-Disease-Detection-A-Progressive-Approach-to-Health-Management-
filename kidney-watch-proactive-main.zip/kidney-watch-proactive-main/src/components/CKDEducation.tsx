import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Heart, 
  Shield, 
  BookOpen, 
  AlertTriangle, 
  CheckCircle,
  TrendingUp,
  Users,
  Utensils,
  Activity
} from "lucide-react";

const CKDEducation = () => {
  const stages = [
    {
      stage: "Stage 1",
      gfr: "≥90",
      description: "Normal or high kidney function with kidney damage",
      color: "bg-success",
      recommendations: [
        "Control blood pressure",
        "Manage diabetes",
        "Regular monitoring",
        "Healthy lifestyle"
      ]
    },
    {
      stage: "Stage 2",
      gfr: "60-89",
      description: "Mildly decreased kidney function with kidney damage",
      color: "bg-success",
      recommendations: [
        "Address underlying causes",
        "Slow progression",
        "Regular check-ups",
        "Medication adherence"
      ]
    },
    {
      stage: "Stage 3A",
      gfr: "45-59",
      description: "Moderate decrease in kidney function",
      color: "bg-warning",
      recommendations: [
        "Nephrology referral",
        "Bone health monitoring",
        "Anemia screening",
        "Cardiovascular risk assessment"
      ]
    },
    {
      stage: "Stage 3B",
      gfr: "30-44",
      description: "Moderate to severe decrease in kidney function",
      color: "bg-warning",
      recommendations: [
        "Prepare for renal replacement therapy",
        "Nutritional counseling",
        "Medication adjustments",
        "Complications management"
      ]
    },
    {
      stage: "Stage 4",
      gfr: "15-29",
      description: "Severe decrease in kidney function",
      color: "bg-destructive",
      recommendations: [
        "Prepare for dialysis or transplant",
        "Vascular access planning",
        "Education on treatment options",
        "Advanced care planning"
      ]
    },
    {
      stage: "Stage 5",
      gfr: "<15",
      description: "Kidney failure",
      color: "bg-destructive",
      recommendations: [
        "Start renal replacement therapy",
        "Dialysis or transplant",
        "Intensive monitoring",
        "Quality of life focus"
      ]
    }
  ];

  const riskFactors = [
    {
      icon: <Heart className="w-5 h-5" />,
      title: "Diabetes",
      description: "Leading cause of CKD. High blood sugar damages kidney blood vessels.",
      prevention: "Maintain HbA1c <7%, regular monitoring"
    },
    {
      icon: <TrendingUp className="w-5 h-5" />,
      title: "High Blood Pressure",
      description: "Damages kidney blood vessels and reduces filtering ability.",
      prevention: "Keep BP <130/80 mmHg, lifestyle modifications"
    },
    {
      icon: <Users className="w-5 h-5" />,
      title: "Family History",
      description: "Genetic predisposition increases risk of kidney disease.",
      prevention: "Regular screening, early detection measures"
    },
    {
      icon: <Activity className="w-5 h-5" />,
      title: "Age & Ethnicity",
      description: "Risk increases with age. Higher rates in certain ethnic groups.",
      prevention: "Regular health check-ups, lifestyle management"
    }
  ];

  const dietTips = [
    {
      category: "Protein",
      recommendation: "Moderate protein intake",
      details: "0.8-1.0 g/kg body weight for stages 1-2, may need restriction in later stages",
      foods: "Lean meats, fish, eggs, dairy in moderation"
    },
    {
      category: "Sodium",
      recommendation: "Limit to <2,300mg daily",
      details: "Reduces blood pressure and fluid retention",
      foods: "Fresh foods, herbs and spices instead of salt"
    },
    {
      category: "Phosphorus",
      recommendation: "May need restriction in advanced stages",
      details: "Prevents bone disease and vascular calcification",
      foods: "Limit processed foods, certain dairy products"
    },
    {
      category: "Potassium",
      recommendation: "Monitor based on lab values",
      details: "Important for heart rhythm, may need restriction",
      foods: "Fruits and vegetables as recommended by dietitian"
    }
  ];

  return (
    <div className="space-y-6">
      <div className="text-center space-y-4">
        <h2 className="text-3xl font-bold text-primary">Understanding Chronic Kidney Disease</h2>
        <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
          Comprehensive guide to kidney health, risk factors, and management strategies
        </p>
      </div>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="stages">CKD Stages</TabsTrigger>
          <TabsTrigger value="risk-factors">Risk Factors</TabsTrigger>
          <TabsTrigger value="management">Management</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="shadow-card">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <BookOpen className="w-6 h-6 text-primary" />
                  <CardTitle>What is CKD?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-muted-foreground">
                  Chronic Kidney Disease (CKD) is a condition where kidneys gradually lose their ability to filter waste and excess fluid from the blood over time.
                </p>
                <div className="space-y-2">
                  <h4 className="font-semibold">Key Facts:</h4>
                  <ul className="space-y-1 text-sm">
                    <li className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-success" />
                      Affects 37 million Americans
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-success" />
                      Often develops slowly over years
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-success" />
                      Early stages often have no symptoms
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-success" />
                      Early detection can slow progression
                    </li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-card">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Shield className="w-6 h-6 text-secondary" />
                  <CardTitle>Early Detection Benefits</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-muted-foreground">
                  Early detection and treatment can significantly slow disease progression and improve quality of life.
                </p>
                <div className="space-y-2">
                  <h4 className="font-semibold">Benefits include:</h4>
                  <ul className="space-y-1 text-sm">
                    <li className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-success" />
                      Slower progression to kidney failure
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-success" />
                      Better management of complications
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-success" />
                      Reduced cardiovascular risk
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-success" />
                      More treatment options available
                    </li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="shadow-card bg-gradient-soft">
            <CardHeader>
              <CardTitle className="text-primary">Key Warning Signs</CardTitle>
              <CardDescription>Contact your healthcare provider if you experience:</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-warning">
                    <AlertTriangle className="w-4 h-4" />
                    <span className="font-medium">Fatigue and weakness</span>
                  </div>
                  <div className="flex items-center gap-2 text-warning">
                    <AlertTriangle className="w-4 h-4" />
                    <span className="font-medium">Swelling in legs, ankles, or feet</span>
                  </div>
                  <div className="flex items-center gap-2 text-warning">
                    <AlertTriangle className="w-4 h-4" />
                    <span className="font-medium">Changes in urination</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-warning">
                    <AlertTriangle className="w-4 h-4" />
                    <span className="font-medium">Persistent nausea</span>
                  </div>
                  <div className="flex items-center gap-2 text-warning">
                    <AlertTriangle className="w-4 h-4" />
                    <span className="font-medium">Loss of appetite</span>
                  </div>
                  <div className="flex items-center gap-2 text-warning">
                    <AlertTriangle className="w-4 h-4" />
                    <span className="font-medium">Difficulty concentrating</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="stages" className="space-y-6">
          <Card className="shadow-card">
            <CardHeader>
              <CardTitle>CKD Stages Based on eGFR</CardTitle>
              <CardDescription>
                Chronic Kidney Disease is classified into 5 stages based on estimated Glomerular Filtration Rate (eGFR)
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {stages.map((stage, index) => (
                  <div key={index} className="border rounded-lg p-4 hover:shadow-card transition-shadow">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <Badge className={`${stage.color} text-white`}>
                          {stage.stage}
                        </Badge>
                        <div>
                          <h4 className="font-semibold">{stage.description}</h4>
                          <p className="text-sm text-muted-foreground">eGFR: {stage.gfr} mL/min/1.73m²</p>
                        </div>
                      </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <h5 className="font-medium mb-2">Key Recommendations:</h5>
                        <ul className="space-y-1">
                          {stage.recommendations.map((rec, recIndex) => (
                            <li key={recIndex} className="flex items-center gap-2 text-sm">
                              <CheckCircle className="w-3 h-3 text-success" />
                              {rec}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="risk-factors" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {riskFactors.map((factor, index) => (
              <Card key={index} className="shadow-card">
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <div className="p-2 bg-primary-soft rounded-lg text-primary">
                      {factor.icon}
                    </div>
                    <CardTitle className="text-lg">{factor.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p className="text-muted-foreground">{factor.description}</p>
                  <div className="p-3 bg-secondary-soft rounded-lg">
                    <h5 className="font-medium text-secondary mb-1">Prevention Strategy:</h5>
                    <p className="text-sm text-secondary/80">{factor.prevention}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="management" className="space-y-6">
          <Card className="shadow-card">
            <CardHeader>
              <div className="flex items-center gap-2">
                <Utensils className="w-6 h-6 text-primary" />
                <CardTitle>Dietary Management</CardTitle>
              </div>
              <CardDescription>
                Proper nutrition is crucial for managing CKD and slowing progression
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {dietTips.map((tip, index) => (
                  <div key={index} className="border rounded-lg p-4">
                    <h4 className="font-semibold text-primary mb-2">{tip.category}</h4>
                    <div className="space-y-2">
                      <p className="font-medium text-sm">{tip.recommendation}</p>
                      <p className="text-sm text-muted-foreground">{tip.details}</p>
                      <div className="p-2 bg-accent rounded text-sm">
                        <strong>Foods:</strong> {tip.foods}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="shadow-card">
              <CardHeader>
                <CardTitle className="text-primary">Lifestyle Modifications</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-success" />
                  <span className="text-sm">Regular exercise (30 min, 5x/week)</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-success" />
                  <span className="text-sm">Quit smoking and limit alcohol</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-success" />
                  <span className="text-sm">Maintain healthy weight</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-success" />
                  <span className="text-sm">Stay adequately hydrated</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-success" />
                  <span className="text-sm">Manage stress effectively</span>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-card">
              <CardHeader>
                <CardTitle className="text-primary">Monitoring Schedule</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center gap-2">
                  <Activity className="w-4 h-4 text-primary" />
                  <span className="text-sm">Regular blood pressure checks</span>
                </div>
                <div className="flex items-center gap-2">
                  <Activity className="w-4 h-4 text-primary" />
                  <span className="text-sm">Quarterly lab work (eGFR, creatinine)</span>
                </div>
                <div className="flex items-center gap-2">
                  <Activity className="w-4 h-4 text-primary" />
                  <span className="text-sm">Annual urine protein testing</span>
                </div>
                <div className="flex items-center gap-2">
                  <Activity className="w-4 h-4 text-primary" />
                  <span className="text-sm">Diabetes monitoring (if applicable)</span>
                </div>
                <div className="flex items-center gap-2">
                  <Activity className="w-4 h-4 text-primary" />
                  <span className="text-sm">Nephrology follow-up as recommended</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default CKDEducation;