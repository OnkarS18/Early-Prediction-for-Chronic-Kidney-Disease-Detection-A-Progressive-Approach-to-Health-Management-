import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, Minus, Activity, Heart, Droplets, TestTube } from "lucide-react";

interface MetricData {
  label: string;
  value: number;
  unit: string;
  normalRange: string;
  status: 'normal' | 'warning' | 'critical';
  trend: 'up' | 'down' | 'stable';
  description: string;
  icon: React.ReactNode;
}

const HealthMetrics = () => {
  const metrics: MetricData[] = [
    {
      label: "Serum Creatinine",
      value: 1.2,
      unit: "mg/dL",
      normalRange: "0.6-1.2",
      status: "normal",
      trend: "stable",
      description: "Measures kidney function and waste filtration",
      icon: <TestTube className="w-5 h-5" />
    },
    {
      label: "Blood Urea Nitrogen",
      value: 35,
      unit: "mg/dL",
      normalRange: "15-40",
      status: "warning",
      trend: "up",
      description: "Indicates kidney's ability to remove waste",
      icon: <Droplets className="w-5 h-5" />
    },
    {
      label: "eGFR",
      value: 75,
      unit: "mL/min/1.73m²",
      normalRange: ">60",
      status: "normal",
      trend: "down",
      description: "Estimated Glomerular Filtration Rate",
      icon: <Activity className="w-5 h-5" />
    },
    {
      label: "Hemoglobin",
      value: 11.5,
      unit: "g/dL",
      normalRange: "12-16",
      status: "warning",
      trend: "down",
      description: "Red blood cell count, may indicate anemia",
      icon: <Heart className="w-5 h-5" />
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'normal': return 'text-success';
      case 'warning': return 'text-warning';
      case 'critical': return 'text-destructive';
      default: return 'text-muted-foreground';
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'normal': return 'bg-success-soft text-success';
      case 'warning': return 'bg-warning-soft text-warning';
      case 'critical': return 'bg-destructive/10 text-destructive';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'up': return <TrendingUp className="w-4 h-4 text-warning" />;
      case 'down': return <TrendingDown className="w-4 h-4 text-destructive" />;
      case 'stable': return <Minus className="w-4 h-4 text-success" />;
      default: return <Minus className="w-4 h-4 text-muted-foreground" />;
    }
  };

  const getProgressValue = (value: number, status: string) => {
    switch (status) {
      case 'normal': return 85;
      case 'warning': return 60;
      case 'critical': return 25;
      default: return 50;
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-primary mb-2">Health Metrics Dashboard</h2>
        <p className="text-muted-foreground">Monitor key indicators for kidney health</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {metrics.map((metric, index) => (
          <Card key={index} className="shadow-card hover:shadow-medical transition-shadow duration-300">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className={`p-2 rounded-lg bg-primary-soft ${getStatusColor(metric.status)}`}>
                    {metric.icon}
                  </div>
                  <div>
                    <CardTitle className="text-lg">{metric.label}</CardTitle>
                    <CardDescription className="text-sm">{metric.description}</CardDescription>
                  </div>
                </div>
                {getTrendIcon(metric.trend)}
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-baseline gap-2">
                <span className={`text-3xl font-bold ${getStatusColor(metric.status)}`}>
                  {metric.value}
                </span>
                <span className="text-muted-foreground">{metric.unit}</span>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Normal Range: {metric.normalRange}</span>
                  <Badge className={getStatusBadge(metric.status)}>
                    {metric.status.toUpperCase()}
                  </Badge>
                </div>
                <Progress 
                  value={getProgressValue(metric.value, metric.status)} 
                  className="h-2"
                />
              </div>

              {metric.status !== 'normal' && (
                <div className={`p-3 rounded-lg border ${
                  metric.status === 'warning' 
                    ? 'bg-warning-soft border-warning/20' 
                    : 'bg-destructive/10 border-destructive/20'
                }`}>
                  <p className={`text-sm ${
                    metric.status === 'warning' ? 'text-warning' : 'text-destructive'
                  }`}>
                    {metric.status === 'warning' 
                      ? 'Monitor closely and follow up with healthcare provider'
                      : 'Immediate medical attention recommended'
                    }
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Summary Card */}
      <Card className="shadow-card bg-gradient-soft">
        <CardHeader>
          <CardTitle className="text-primary">Overall Health Status</CardTitle>
          <CardDescription>Based on current metric analysis</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <Activity className="w-5 h-5 text-primary" />
                <span className="font-semibold">Kidney Function Assessment</span>
              </div>
              <Progress value={72} className="h-3" />
              <p className="text-sm text-muted-foreground mt-2">
                72% - Good kidney function with some areas requiring attention
              </p>
            </div>
            <Badge className="bg-warning-soft text-warning px-4 py-2">
              MONITOR
            </Badge>
          </div>
          
          <div className="mt-4 p-4 bg-primary-soft rounded-lg">
            <h4 className="font-semibold text-primary mb-2">Recommendations:</h4>
            <ul className="text-sm space-y-1 text-primary/80">
              <li>• Schedule follow-up appointment within 3 months</li>
              <li>• Continue current medications as prescribed</li>
              <li>• Monitor blood pressure regularly</li>
              <li>• Maintain healthy diet and hydration</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default HealthMetrics;