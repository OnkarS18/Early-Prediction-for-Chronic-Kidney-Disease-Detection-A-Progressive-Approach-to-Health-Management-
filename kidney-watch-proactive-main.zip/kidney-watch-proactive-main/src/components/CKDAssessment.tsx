import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import { AlertCircle, CheckCircle, Activity, TrendingUp } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface LabValues {
  age: number;
  bloodPressure: number;
  specificGravity: number;
  albumin: number;
  sugar: number;
  redBloodCells: number;
  pusCell: number;
  pusCellClumps: number;
  bacteria: number;
  bloodGlucoseRandom: number;
  bloodUrea: number;
  serumCreatinine: number;
  sodium: number;
  potassium: number;
  hemoglobin: number;
  packedCellVolume: number;
  whiteBloodCellCount: number;
  redBloodCellCount: number;
  hypertension: number;
  diabetesMellitus: number;
  coronaryArteryDisease: number;
  appetite: number;
  pedalEdema: number;
  anemia: number;
}

interface RiskAssessment {
  riskLevel: 'low' | 'moderate' | 'high' | 'critical';
  probability: number;
  keyFactors: string[];
  recommendations: string[];
}

const CKDAssessment = () => {
  const { toast } = useToast();
  const [labValues, setLabValues] = useState<LabValues>({
    age: 0,
    bloodPressure: 0,
    specificGravity: 0,
    albumin: 0,
    sugar: 0,
    redBloodCells: 0,
    pusCell: 0,
    pusCellClumps: 0,
    bacteria: 0,
    bloodGlucoseRandom: 0,
    bloodUrea: 0,
    serumCreatinine: 0,
    sodium: 0,
    potassium: 0,
    hemoglobin: 0,
    packedCellVolume: 0,
    whiteBloodCellCount: 0,
    redBloodCellCount: 0,
    hypertension: 0,
    diabetesMellitus: 0,
    coronaryArteryDisease: 0,
    appetite: 0,
    pedalEdema: 0,
    anemia: 0,
  });

  const [riskAssessment, setRiskAssessment] = useState<RiskAssessment | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Simplified risk calculation algorithm (in real app, this would call your ML model)
  const calculateRisk = (values: LabValues): RiskAssessment => {
    let riskScore = 0;
    const keyFactors: string[] = [];
    const recommendations: string[] = [];

    // Age factor
    if (values.age > 60) {
      riskScore += 15;
      keyFactors.push("Advanced age");
    }

    // Serum Creatinine (key indicator)
    if (values.serumCreatinine > 1.5) {
      riskScore += 25;
      keyFactors.push("Elevated serum creatinine");
      recommendations.push("Immediate nephrology consultation recommended");
    }

    // Blood Urea
    if (values.bloodUrea > 50) {
      riskScore += 20;
      keyFactors.push("High blood urea");
    }

    // Hemoglobin (anemia indicator)
    if (values.hemoglobin < 12) {
      riskScore += 15;
      keyFactors.push("Anemia detected");
      recommendations.push("Iron supplements and dietary counseling");
    }

    // Diabetes
    if (values.diabetesMellitus === 1) {
      riskScore += 20;
      keyFactors.push("Diabetes mellitus");
      recommendations.push("Strict glucose control essential");
    }

    // Hypertension
    if (values.hypertension === 1) {
      riskScore += 15;
      keyFactors.push("Hypertension");
      recommendations.push("Blood pressure management required");
    }

    // Proteinuria (albumin)
    if (values.albumin > 1) {
      riskScore += 18;
      keyFactors.push("Proteinuria detected");
    }

    // Edema
    if (values.pedalEdema === 1) {
      riskScore += 12;
      keyFactors.push("Pedal edema");
    }

    // Standard recommendations
    recommendations.push("Regular follow-up with healthcare provider");
    recommendations.push("Maintain healthy diet and exercise");
    recommendations.push("Stay adequately hydrated");

    let riskLevel: 'low' | 'moderate' | 'high' | 'critical';
    if (riskScore < 20) riskLevel = 'low';
    else if (riskScore < 50) riskLevel = 'moderate';
    else if (riskScore < 80) riskLevel = 'high';
    else riskLevel = 'critical';

    return {
      riskLevel,
      probability: Math.min(riskScore, 95),
      keyFactors,
      recommendations
    };
  };

  const handleInputChange = (field: keyof LabValues, value: string) => {
    setLabValues(prev => ({
      ...prev,
      [field]: parseFloat(value) || 0
    }));
  };

  const handleAssessment = async () => {
    setIsLoading(true);
    
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const assessment = calculateRisk(labValues);
    setRiskAssessment(assessment);
    setIsLoading(false);

    toast({
      title: "Assessment Complete",
      description: `Risk level: ${assessment.riskLevel.toUpperCase()}`,
      variant: assessment.riskLevel === 'critical' || assessment.riskLevel === 'high' ? "destructive" : "default",
    });
  };

  const getRiskColor = (level: string) => {
    switch (level) {
      case 'low': return 'bg-success';
      case 'moderate': return 'bg-warning';
      case 'high': return 'bg-destructive';
      case 'critical': return 'bg-destructive';
      default: return 'bg-muted';
    }
  };

  const getRiskIcon = (level: string) => {
    switch (level) {
      case 'low': return <CheckCircle className="w-5 h-5" />;
      case 'moderate': return <Activity className="w-5 h-5" />;
      case 'high': return <AlertCircle className="w-5 h-5" />;
      case 'critical': return <TrendingUp className="w-5 h-5" />;
      default: return <Activity className="w-5 h-5" />;
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <Card className="shadow-card">
        <CardHeader>
          <CardTitle className="text-2xl text-primary">CKD Risk Assessment</CardTitle>
          <CardDescription>
            Enter your medical test results for personalized kidney disease risk analysis
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Basic Information */}
          <div>
            <h3 className="text-lg font-semibold mb-4 text-primary">Basic Information</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="age">Age (years)</Label>
                <Input
                  id="age"
                  type="number"
                  placeholder="Enter age"
                  value={labValues.age || ''}
                  onChange={(e) => handleInputChange('age', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="bloodPressure">Blood Pressure (mmHg)</Label>
                <Input
                  id="bloodPressure"
                  type="number"
                  placeholder="Systolic BP"
                  value={labValues.bloodPressure || ''}
                  onChange={(e) => handleInputChange('bloodPressure', e.target.value)}
                />
              </div>
            </div>
          </div>

          <Separator />

          {/* Laboratory Values */}
          <div>
            <h3 className="text-lg font-semibold mb-4 text-primary">Laboratory Values</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="serumCreatinine">Serum Creatinine (mg/dL)</Label>
                <Input
                  id="serumCreatinine"
                  type="number"
                  step="0.1"
                  placeholder="Normal: 0.6-1.2"
                  value={labValues.serumCreatinine || ''}
                  onChange={(e) => handleInputChange('serumCreatinine', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="bloodUrea">Blood Urea (mg/dL)</Label>
                <Input
                  id="bloodUrea"
                  type="number"
                  placeholder="Normal: 15-40"
                  value={labValues.bloodUrea || ''}
                  onChange={(e) => handleInputChange('bloodUrea', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="hemoglobin">Hemoglobin (g/dL)</Label>
                <Input
                  id="hemoglobin"
                  type="number"
                  step="0.1"
                  placeholder="Normal: 12-16"
                  value={labValues.hemoglobin || ''}
                  onChange={(e) => handleInputChange('hemoglobin', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="albumin">Albumin (0-5 scale)</Label>
                <Input
                  id="albumin"
                  type="number"
                  placeholder="0=Normal, 5=High"
                  value={labValues.albumin || ''}
                  onChange={(e) => handleInputChange('albumin', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="bloodGlucoseRandom">Random Blood Glucose (mg/dL)</Label>
                <Input
                  id="bloodGlucoseRandom"
                  type="number"
                  placeholder="Normal: 70-140"
                  value={labValues.bloodGlucoseRandom || ''}
                  onChange={(e) => handleInputChange('bloodGlucoseRandom', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="specificGravity">Specific Gravity</Label>
                <Input
                  id="specificGravity"
                  type="number"
                  step="0.001"
                  placeholder="Normal: 1.005-1.030"
                  value={labValues.specificGravity || ''}
                  onChange={(e) => handleInputChange('specificGravity', e.target.value)}
                />
              </div>
            </div>
          </div>

          <Separator />

          {/* Medical History */}
          <div>
            <h3 className="text-lg font-semibold mb-4 text-primary">Medical History</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="hypertension">Hypertension</Label>
                <select
                  id="hypertension"
                  className="w-full p-2 border rounded-md"
                  value={labValues.hypertension}
                  onChange={(e) => handleInputChange('hypertension', e.target.value)}
                >
                  <option value={0}>No</option>
                  <option value={1}>Yes</option>
                </select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="diabetesMellitus">Diabetes Mellitus</Label>
                <select
                  id="diabetesMellitus"
                  className="w-full p-2 border rounded-md"
                  value={labValues.diabetesMellitus}
                  onChange={(e) => handleInputChange('diabetesMellitus', e.target.value)}
                >
                  <option value={0}>No</option>
                  <option value={1}>Yes</option>
                </select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="pedalEdema">Pedal Edema</Label>
                <select
                  id="pedalEdema"
                  className="w-full p-2 border rounded-md"
                  value={labValues.pedalEdema}
                  onChange={(e) => handleInputChange('pedalEdema', e.target.value)}
                >
                  <option value={0}>No</option>
                  <option value={1}>Yes</option>
                </select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="anemia">Anemia</Label>
                <select
                  id="anemia"
                  className="w-full p-2 border rounded-md"
                  value={labValues.anemia}
                  onChange={(e) => handleInputChange('anemia', e.target.value)}
                >
                  <option value={0}>No</option>
                  <option value={1}>Yes</option>
                </select>
              </div>
            </div>
          </div>

          <Button 
            onClick={handleAssessment} 
            disabled={isLoading}
            className="w-full"
            size="lg"
          >
            {isLoading ? "Analyzing..." : "Analyze CKD Risk"}
          </Button>
        </CardContent>
      </Card>

      {/* Risk Assessment Results */}
      {riskAssessment && (
        <Card className="shadow-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {getRiskIcon(riskAssessment.riskLevel)}
              Risk Assessment Results
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="text-center">
              <div className={`inline-flex items-center px-4 py-2 rounded-full text-white font-semibold ${getRiskColor(riskAssessment.riskLevel)}`}>
                {riskAssessment.riskLevel.toUpperCase()} RISK
              </div>
              <div className="mt-4">
                <div className="text-3xl font-bold text-primary">
                  {riskAssessment.probability}%
                </div>
                <div className="text-muted-foreground">Risk Probability</div>
                <Progress value={riskAssessment.probability} className="mt-2" />
              </div>
            </div>

            <Separator />

            <div>
              <h4 className="font-semibold mb-3 text-primary">Key Risk Factors Identified:</h4>
              <div className="flex flex-wrap gap-2">
                {riskAssessment.keyFactors.map((factor, index) => (
                  <Badge key={index} variant="secondary">
                    {factor}
                  </Badge>
                ))}
              </div>
            </div>

            <div>
              <h4 className="font-semibold mb-3 text-primary">Recommendations:</h4>
              <ul className="space-y-2">
                {riskAssessment.recommendations.map((rec, index) => (
                  <li key={index} className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-success mt-0.5 flex-shrink-0" />
                    <span className="text-sm">{rec}</span>
                  </li>
                ))}
              </ul>
            </div>

            {riskAssessment.riskLevel === 'high' || riskAssessment.riskLevel === 'critical' && (
              <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-4">
                <div className="flex items-start gap-2">
                  <AlertCircle className="w-5 h-5 text-destructive mt-0.5" />
                  <div>
                    <h5 className="font-semibold text-destructive">Urgent Medical Attention Required</h5>
                    <p className="text-sm text-destructive/80 mt-1">
                      Please consult with a nephrologist or your healthcare provider immediately for further evaluation and treatment planning.
                    </p>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default CKDAssessment;