import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Activity, Heart, BookOpen, TrendingUp } from "lucide-react";
import CKDAssessment from "@/components/CKDAssessment";
import HealthMetrics from "@/components/HealthMetrics";
import CKDEducation from "@/components/CKDEducation";
import heroImage from "@/assets/ckd-hero.jpg";

const Index = () => {
  const [activeTab, setActiveTab] = useState("assessment");

  return (
    <div className="min-h-screen bg-gradient-soft">
      {/* Hero Section */}
      <div className="relative bg-gradient-hero text-white py-20">
        <div className="absolute inset-0 bg-black/20"></div>
        <div 
          className="absolute inset-0 bg-cover bg-center opacity-30"
          style={{ backgroundImage: `url(${heroImage})` }}
        ></div>
        <div className="relative max-w-6xl mx-auto px-4 text-center">
          <h1 className="text-5xl font-bold mb-6">
            Early Prediction for Chronic Kidney Disease Detection
          </h1>
          <p className="text-xl mb-8 max-w-3xl mx-auto opacity-90">
            A Progressive Approach to Health Management - Empowering early detection, 
            personalized risk assessment, and proactive healthcare decisions
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              variant="secondary"
              onClick={() => setActiveTab("assessment")}
              className="shadow-glow"
            >
              <Activity className="w-5 h-5 mr-2" />
              Start Risk Assessment
            </Button>
            <Button 
              size="lg" 
              variant="outline"
              onClick={() => setActiveTab("education")}
              className="bg-white/10 border-white/30 text-white hover:bg-white/20"
            >
              <BookOpen className="w-5 h-5 mr-2" />
              Learn About CKD
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-6xl mx-auto px-4 py-12">
        {/* Feature Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <Card className="shadow-card text-center hover:shadow-medical transition-shadow duration-300">
            <CardHeader>
              <div className="mx-auto w-12 h-12 bg-primary-soft rounded-full flex items-center justify-center mb-4">
                <TrendingUp className="w-6 h-6 text-primary" />
              </div>
              <CardTitle className="text-primary">Early Detection</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Advanced ML algorithms analyze routine test results to identify CKD risk before symptoms appear
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="shadow-card text-center hover:shadow-medical transition-shadow duration-300">
            <CardHeader>
              <div className="mx-auto w-12 h-12 bg-secondary-soft rounded-full flex items-center justify-center mb-4">
                <Activity className="w-6 h-6 text-secondary" />
              </div>
              <CardTitle className="text-primary">Risk Assessment</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Comprehensive analysis of medical history, lab values, and risk factors for personalized evaluation
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="shadow-card text-center hover:shadow-medical transition-shadow duration-300">
            <CardHeader>
              <div className="mx-auto w-12 h-12 bg-success-soft rounded-full flex items-center justify-center mb-4">
                <Heart className="w-6 h-6 text-success" />
              </div>
              <CardTitle className="text-primary">Health Management</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Evidence-based recommendations and monitoring tools to support kidney health and prevent progression
              </CardDescription>
            </CardContent>
          </Card>
        </div>

        {/* Main Application Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3 mb-8">
            <TabsTrigger value="assessment" className="text-sm sm:text-base">
              Risk Assessment
            </TabsTrigger>
            <TabsTrigger value="metrics" className="text-sm sm:text-base">
              Health Metrics
            </TabsTrigger>
            <TabsTrigger value="education" className="text-sm sm:text-base">
              Education
            </TabsTrigger>
          </TabsList>

          <TabsContent value="assessment">
            <CKDAssessment />
          </TabsContent>

          <TabsContent value="metrics">
            <HealthMetrics />
          </TabsContent>

          <TabsContent value="education">
            <CKDEducation />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Index;